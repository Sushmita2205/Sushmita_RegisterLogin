package com.lti.model;




import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Entity
@Table(name ="beneficiary_details")
@Scope(scopeName="prototype")
@Component

public class AddBeneficiary {

	@Id
	
	private int beneficiary_account_no;
	private String beneficiary_name;
	private String beneficiary_branch_ifsc;
	private int account_no;
	public AddBeneficiary() {
		super();
		
	}
	public AddBeneficiary(int beneficiary_account_no, String beneficiary_name, String beneficiary_branch_ifsc,
			int account_no) {
		super();
		this.beneficiary_account_no = beneficiary_account_no;
		this.beneficiary_name = beneficiary_name;
		this.beneficiary_branch_ifsc = beneficiary_branch_ifsc;
		this.account_no = account_no;
	}
	public int getBeneficiary_account_no() {
		return beneficiary_account_no;
	}
	public void setBeneficiary_account_no(int beneficiary_account_no) {
		this.beneficiary_account_no = beneficiary_account_no;
	}
	public String getBeneficiary_name() {
		return beneficiary_name;
	}
	public void setBeneficiary_name(String beneficiary_name) {
		this.beneficiary_name = beneficiary_name;
	}
	public String getBeneficiary_branch_ifsc() {
		return beneficiary_branch_ifsc;
	}
	public void setBeneficiary_branch_ifsc(String beneficiary_branch_ifsc) {
		this.beneficiary_branch_ifsc = beneficiary_branch_ifsc;
	}
	public int getAccount_no() {
		return account_no;
	}
	public void setAccount_no(int account_no) {
		this.account_no = account_no;
	}
	@Override
	public String toString() {
		return "AddBeneficiary [beneficiary_account_no=" + beneficiary_account_no + ", beneficiary_name="
				+ beneficiary_name + ", beneficiary_branch_ifsc=" + beneficiary_branch_ifsc + ", account_no="
				+ account_no + "]";
	}

}
