package com.lti.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.lti.model.AddBeneficiary;

@Repository
public class BeneficiaryDaoImpl implements BeneficiaryDao {

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	@Transactional
	public int createBeneficiary(AddBeneficiary beneficiary) {
		entityManager.persist(beneficiary);
		return 1;
	}

	@Override
	public List<AddBeneficiary> getBeneficiaries() {
		String jpql = "From AddBeneficiary";
		TypedQuery<AddBeneficiary> typed = entityManager.createQuery(jpql, AddBeneficiary.class);
		return typed.getResultList();
	}

	@Override
	public AddBeneficiary readCustomerByB_id(int beneficiary_account_no) {
		return entityManager.find(AddBeneficiary.class, beneficiary_account_no);

	}
	
	

}
