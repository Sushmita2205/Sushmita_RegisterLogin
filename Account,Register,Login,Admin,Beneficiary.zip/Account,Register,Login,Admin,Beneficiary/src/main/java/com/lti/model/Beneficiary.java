package com.lti.model;




import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Entity
@Table(name ="ben")
@Scope(scopeName="prototype")
@Component

public class Beneficiary {

	@Id
	@Column(name="beneficiary_account_no")
	private int beneficiaryAccountNo;
	@Column(name="beneficiary_name")
	private String beneficiaryName;
	@Column(name="beneficiary_branch_ifsc")
	private String beneficiaryBranchIfsc;
	@Transient
	private int account_no;
	public Beneficiary() {
		super();
	}
	public int getBeneficiaryAccountNo() {
		return beneficiaryAccountNo;
	}
	public void setBeneficiaryAccountNo(int beneficiaryAccountNo) {
		this.beneficiaryAccountNo = beneficiaryAccountNo;
	}
	public String getBeneficiaryName() {
		return beneficiaryName;
	}
	public void setBeneficiaryName(String beneficiaryName) {
		this.beneficiaryName = beneficiaryName;
	}
	public String getBeneficiaryBranchIfsc() {
		return beneficiaryBranchIfsc;
	}
	public void setBeneficiaryBranchIfsc(String beneficiaryBranchIfsc) {
		this.beneficiaryBranchIfsc = beneficiaryBranchIfsc;
	}
	public int getAccount_no() {
		return account_no;
	}
	public void setAccount_no(int account_no) {
		this.account_no = account_no;
	}
	public Beneficiary(int beneficiaryAccountNo, String beneficiaryName, String beneficiaryBranchIfsc, int account_no) {
		super();
		this.beneficiaryAccountNo = beneficiaryAccountNo;
		this.beneficiaryName = beneficiaryName;
		this.beneficiaryBranchIfsc = beneficiaryBranchIfsc;
		this.account_no = account_no;
	}
	@Override
	public String toString() {
		return "Beneficiary [beneficiaryAccountNo=" + beneficiaryAccountNo + ", beneficiaryName=" + beneficiaryName
				+ ", beneficiaryBranchIfsc=" + beneficiaryBranchIfsc + ", account_no=" + account_no + "]";
	}
	
	
}
