package com.lti.dao;

import java.util.List;

import com.lti.model.AddBeneficiary;




public interface BeneficiaryDao {
	public int createBeneficiary(AddBeneficiary beneficiary);
	public List<AddBeneficiary> getBeneficiaries();
	public AddBeneficiary readCustomerByB_id(int beneficiary_account_no);
}
