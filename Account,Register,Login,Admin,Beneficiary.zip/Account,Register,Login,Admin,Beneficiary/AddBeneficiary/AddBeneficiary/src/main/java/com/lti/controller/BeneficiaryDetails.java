package com.lti.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.lti.model.AddBeneficiary;

import com.lti.service.BeneficiaryService;

@RestController
@RequestMapping(path ="beneficiary")
@CrossOrigin
public class BeneficiaryDetails {

	@Autowired
	private BeneficiaryService service;

	// http://localhost:8181/beneficiary
	@RequestMapping(method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<String> addBeneficiary(@RequestBody AddBeneficiary beneficiary) {
		ResponseEntity<String> response;
		boolean result=service.addBeneficiary(beneficiary);
		if(result)
		{
		response=new ResponseEntity<String>("Beneficiary  is added",HttpStatus.CREATED);	
		}
		else
		{
			response=new ResponseEntity<String>("beneficiary is not added",HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;

	}
	// http://localhost:8181/beneficiary
	@RequestMapping(method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<AddBeneficiary> findAllBenficiaries() {
		List<AddBeneficiary> beneficiary = service.getBeneficiaries();

		return beneficiary;
	}

	// http://localhost:8181/beneficiary
	@RequestMapping(path="{beneficiary_account_no }" ,method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public AddBeneficiary findCustomerByB_id(@PathVariable("beneficiary_account_no ") int beneficiary_account_no ) {
		AddBeneficiary customer = service.findCustomerByB_id(beneficiary_account_no );
		return customer;
	}

	
}
