package com.lti.service;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.dao.BeneficiaryDao;
import com.lti.model.AddBeneficiary;






@Service("service")
public class BeneficiaryServiceImpl implements BeneficiaryService {
	@Autowired
	private BeneficiaryDao dao;

	public BeneficiaryDao getDao() {
		return dao;
	}

	public void setDao(BeneficiaryDao dao) {
		this.dao = dao;
	}

	@Override
	public boolean addBeneficiary(AddBeneficiary beneficiary) {
		int result = dao.createBeneficiary(beneficiary);
		if (result == 1)
			return true;
		else
			return false;
	}
	@Override
	public List<AddBeneficiary> getBeneficiaries() {
		
		return dao.getBeneficiaries();
	}

	@Override
	public AddBeneficiary findCustomerByB_id(int beneficiary_account_no) {
		return dao.readCustomerByB_id(beneficiary_account_no);
		
	}

}
