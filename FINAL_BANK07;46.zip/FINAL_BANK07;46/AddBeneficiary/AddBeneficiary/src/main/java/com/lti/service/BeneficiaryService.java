package com.lti.service;




import java.util.List;

import com.lti.model.AddBeneficiary;






public interface BeneficiaryService {
	public boolean addBeneficiary(AddBeneficiary beneficiary);
	List<AddBeneficiary> getBeneficiaries();
	public AddBeneficiary findCustomerByB_id(int beneficiary_account_no);
}
