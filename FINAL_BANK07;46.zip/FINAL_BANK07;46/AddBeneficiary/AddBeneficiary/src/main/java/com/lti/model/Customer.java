package com.lti.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Entity
@Component
@Table(name="Cust")
public class Customer {
  @Id
  private int c_id;
  private String c_name;
  private double annual_income;
  private String occupation;
  private String address;
  
  
public Customer() {
	super();
}
public Customer(int c_id, String c_name, double annual_income, String occupation, String address) {
	super();
	this.c_id = c_id;
	this.c_name = c_name;
	this.annual_income = annual_income;
	this.occupation = occupation;
	this.address = address;
}
public int getC_id() {
	return c_id;
}
public void setC_id(int c_id) {
	this.c_id = c_id;
}
public String getC_name() {
	return c_name;
}
public void setC_name(String c_name) {
	this.c_name = c_name;
}
public double getAnnual_income() {
	return annual_income;
}
public void setAnnual_income(double annual_income) {
	this.annual_income = annual_income;
}
public String getOccupation() {
	return occupation;
}
public void setOccupation(String occupation) {
	this.occupation = occupation;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
  
  
  
}
