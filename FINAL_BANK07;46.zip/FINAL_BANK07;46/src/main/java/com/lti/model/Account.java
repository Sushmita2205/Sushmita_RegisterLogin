package com.lti.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope(scopeName="prototype")
@Entity
@Table(name="account1")
public class Account {

	@Id
	@Column(name="account_no")
	private long accountNo;
	@Column(name="account_services")
	private String accountServices;
	@Column(name="account_balance")
	private double accountBalance;
	@Column(name="account_type")
	private String accountType;
	@Column(name="c_id")
	private long customerId;
	@Column(name="admin_id")
	private String adminId;
	@Column(name="branch_ifsc")
	private String branchIfsc;
	public long getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}
	public String getAccountServices() {
		return accountServices;
	}
	public void setAccountServices(String accountServices) {
		this.accountServices = accountServices;
	}
	public double getAccountBalance() {
		return accountBalance;
	}
	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public long getCustomerId() {
		return customerId;
	}
	public void setCustomerId(long customerId) {
		this.customerId = customerId;
	}
	public String getAdminId() {
		return adminId;
	}
	public void setAdminId(String adminId) {
		this.adminId = adminId;
	}
	public String getBranchIfsc() {
		return branchIfsc;
	}
	public void setBranchIfsc(String branchIfsc) {
		this.branchIfsc = branchIfsc;
	}
	public Account(long accountNo, String accountServices, double accountBalance, String accountType, long customerId,
			String adminId, String branchIfsc) {
		super();
		this.accountNo = accountNo;
		this.accountServices = accountServices;
		this.accountBalance = accountBalance;
		this.accountType = accountType;
		this.customerId = customerId;
		this.adminId = adminId;
		this.branchIfsc = branchIfsc;
	}
	@Override
	public String toString() {
		return "Account [accountNo=" + accountNo + ", accountServices=" + accountServices + ", accountBalance="
				+ accountBalance + ", accountType=" + accountType + ", customerId=" + customerId + ", adminId="
				+ adminId + ", branchIfsc=" + branchIfsc + "]";
	}
	public Account() {
		super();
	}
	

	
	
	
}
