package com.lti.model;




import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Entity
@Table(name ="beneficiary_details2")
@Scope(scopeName="prototype")
@Component

public class Beneficiary {

	@Id
	@Column(name="beneficiary_account_no")
	private int beneficiaryAccountNo;
	@Column(name="beneficiary_name")
	private String beneficiaryName;
	@Column(name="beneficiary_branch_ifsc")
	private String beneficiaryBranchIfsc;
	@Column(name="payee_account_no")
	private int accountNo;
	public int getBeneficiaryAccountNo() {
		return beneficiaryAccountNo;
	}
	public void setBeneficiaryAccountNo(int beneficiaryAccountNo) {
		this.beneficiaryAccountNo = beneficiaryAccountNo;
	}
	public String getBeneficiaryName() {
		return beneficiaryName;
	}
	public void setBeneficiaryName(String beneficiaryName) {
		this.beneficiaryName = beneficiaryName;
	}
	public String getBeneficiaryBranchIfsc() {
		return beneficiaryBranchIfsc;
	}
	public void setBeneficiaryBranchIfsc(String beneficiaryBranchIfsc) {
		this.beneficiaryBranchIfsc = beneficiaryBranchIfsc;
	}
	public int getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	public Beneficiary(int beneficiaryAccountNo, String beneficiaryName, String beneficiaryBranchIfsc, int accountNo) {
		super();
		this.beneficiaryAccountNo = beneficiaryAccountNo;
		this.beneficiaryName = beneficiaryName;
		this.beneficiaryBranchIfsc = beneficiaryBranchIfsc;
		this.accountNo = accountNo;
	}
	@Override
	public String toString() {
		return "Beneficiary [beneficiaryAccountNo=" + beneficiaryAccountNo + ", beneficiaryName=" + beneficiaryName
				+ ", beneficiaryBranchIfsc=" + beneficiaryBranchIfsc + ", accountNo=" + accountNo + "]";
	}
	public Beneficiary() {
		super();
	}
	

	
}
