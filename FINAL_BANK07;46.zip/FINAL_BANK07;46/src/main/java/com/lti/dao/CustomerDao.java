package com.lti.dao;

import java.util.List;

import com.lti.model.Account;
import com.lti.model.Admin;
import com.lti.model.Beneficiary;
import com.lti.model.CustomerApplication;
import com.lti.model.Register;
import com.lti.model.Transactions;;

public interface CustomerDao {
	public int createCustomer(CustomerApplication customer);                      //CREATE ACCOUNT
	
	public int registerForWeb(Register register);                                 //REGISTER
	
	public Register validate(String customerUsername,String customerPassword);    //LOGIN
	
	public List<Register> getAllRegistrations();
	
	public List<CustomerApplication> getAllSavingAccount();
	
	public Admin check(String adminId,String adminPassword);                   	 //ADMIN LOGIN
	
	public int createBeneficiary(Beneficiary beneficiary);                		 //ADD BENEFICIARY
	
	public int add(long acc,String recepient);                                     //ADD ACCOUNT
	
	public List<CustomerApplication> getAllCustomers();                          // GET CUSTOMERS
	
	public int updateCustomerStatus(String recepient);                                          // UPDATE STATUS
	
	public int updateAccountBalance(double balance,long accountNo);                       //UPDATE BALANCE
	
	public int cashTransfer(Transactions transaction);  //TRANSFER MONEY

	public Account getAccountByAccountId(long acc);
	
	
}