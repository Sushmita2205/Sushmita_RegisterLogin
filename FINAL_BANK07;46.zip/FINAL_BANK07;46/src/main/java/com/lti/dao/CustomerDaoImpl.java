package com.lti.dao;



import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.lti.model.Account;
import com.lti.model.Admin;
import com.lti.model.Beneficiary;
import com.lti.model.Branch;
import com.lti.model.CustomerApplication;
import com.lti.model.Register;
import com.lti.model.Transactions;

@Repository
public class CustomerDaoImpl implements CustomerDao {
	
	@PersistenceContext
	private EntityManager entityManager;
	@Autowired
	private Register reg;
	@Autowired
	private Admin admin;
	@Autowired
	private Account accounts;
	@Autowired
	private Beneficiary beneficiary;
	@Autowired
	private CustomerApplication customer;
	@Autowired
	private Branch branch;

	@Override
	@Transactional
	public int createCustomer( CustomerApplication customer) {                //CREATE ACCOUNT
		
		entityManager.persist(customer);
		return 1;
	}

	@Override
	@Transactional
	public int registerForWeb(Register register) {                    //REGISTER
	
		entityManager.persist(register);
		
		return 1;
	}
	
	@Override
	public Register validate(String customerUsername,String customerPassword) {           //LOGIN
	
		System.out.println("VALIDATE: "+customerUsername);
		String jpql = "from Register s where s.customerUsername=:customer_username";
		TypedQuery<Register> query=entityManager.createQuery(jpql,Register.class);
		query.setParameter("customer_username", customerUsername);
		System.out.println("-----------------REG>");
		reg=query.getSingleResult();
		System.out.println(customerUsername+ " :" + reg.getCustomerUsername());
		System.out.println(customerPassword +" :"+ reg.getCustomerPassword());
		
		if(customerUsername.equals(reg.getCustomerUsername()) && customerPassword.equals(reg.getCustomerPassword()) ){
			System.out.println("done");
		}
		else{
			System.out.println("Could not Login");
		}
		return reg;
	}
		
	
	@Override
	public List<Register> getAllRegistrations() {               //GET ALL REGISTRATIONS
		String jpql = "From Register";
		TypedQuery<Register> typed = entityManager.createQuery(jpql, Register.class);

		return typed.getResultList();
	}
	
	
	
	@Override
	public List<CustomerApplication> getAllSavingAccount() {
		String jpql = "From CustomerApplication";
		TypedQuery<CustomerApplication> typed = entityManager.createQuery(jpql, CustomerApplication.class);
		List<CustomerApplication> li =(List<CustomerApplication>)typed.getResultList();
		return li;
	}

	@Override
	public Admin check(String adminId, String adminPassword) {       //ADMIN LOGIN
		
		System.out.println("VALIDATE: "+adminId);
		String jpql = "from Admin a where a.adminId=:adminId";
		TypedQuery<Admin> query=entityManager.createQuery(jpql,Admin.class);
		query.setParameter("adminId", adminId);
		System.out.println("-----------------REG>");
		admin=query.getSingleResult();
		System.out.println(adminId+ " :" + admin.getAdminId());
		System.out.println(adminPassword +" :"+ admin.getAdminPassword());
		
		if(adminId.equals(admin.getAdminId()) && adminPassword.equals(admin.getAdminPassword()) ){
			System.out.println("ADMIN LOGIN");
			
		}
		else{
			System.out.println("Could not Login Admin");
		}
		
		System.out.println("HELLO");
		return admin;
	}

		@Override
		@Transactional
		public int createBeneficiary(Beneficiary beneficiary) {             //ADD BENEFICIARY
			entityManager.persist(beneficiary);
			return 1;

		
		

	}
		
		@Override
		@Transactional
		public int add(long acc,String recepient) {                              //ADD ACCOUNT
			
			String jpql = "from CustomerApplication a where a.email=:recepient";
			TypedQuery<CustomerApplication> query=entityManager.createQuery(jpql,CustomerApplication.class);
			query.setParameter("recepient", recepient);
			customer = query.getSingleResult();
			
			customer.setCustomerId(customer.getCustomerId());
			branch.setBranchIfsc("SMT2001");
			admin.setAdminId("suji");
			
			accounts.setAccountNo(acc);
			accounts.setAccountServices("DebitCard");
			accounts.setAccountBalance(20000.0);
			accounts.setAccountType("Savings");
			accounts.setCustomerId(customer.getCustomerId());
			accounts.setBranchIfsc(branch.getBranchIfsc());
			accounts.setAdminId(admin.getAdminId());
	
			entityManager.find(Account.class, accounts.getAccountNo());
			entityManager.persist(accounts);
			System.out.println("ADD ACCOUNT NO");
			System.out.println("Teju");
			return 1;
		}
		
		
		@Override
		public List<CustomerApplication> getAllCustomers() {                             //DISPLAY PENDING CUSTOMERS
			String jpql = "Select c from CustomerApplication c where c.status='Pending'";
			TypedQuery<CustomerApplication> typed = entityManager.createQuery(jpql, CustomerApplication.class);

			return typed.getResultList();
		}

		@Override
		@Transactional
		public int updateCustomerStatus(String recepient) {                           //UPDATE STATUS
			
			String jpql2 = "Update CustomerApplication a set a.status=:status where a.email=:recepient";
			Query query2=entityManager.createQuery(jpql2);
			query2.setParameter("status", "Approved");
			query2.setParameter("recepient", recepient);
			query2.executeUpdate();
			return 1;
		}
		
		@Override
		@Transactional
		public int updateAccountBalance(double balance, long accountNo) {
			String jpql="Update Account s set s.accountBalance=:accountBalance where s.accountNo=:accountNo";
			Query query=entityManager.createQuery(jpql);
			query.setParameter("accountBalance", balance);
			query.setParameter("accountNo", accountNo);
			
			int result=query.executeUpdate();
			return result;
		}

		@Override
		@Transactional
		public int cashTransfer(Transactions transaction) {
			
			
			/*String jpql="Insert into Transaction(transactionId,modeOfPayment,amountCreditDebit,transactionStatus,beneficiaryIfsc,beneficiaryAccountNo,accountNo,branchIfsc,transactionDateTime) values(:;
			Query query=entityManager.createQuery(jpql);
			query.setParameter("accountNo", accountNo);
			int result=query.executeUpdate();
			*/
			entityManager.persist(transaction);
			
			
			return 1;
		}

		@Override
		public Account getAccountByAccountId(long acc) {
			Account account = entityManager.find(Account.class, acc);
			return account;
		}
		

}



	
	
