package com.lti.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.lti.model.Account;
import com.lti.model.Admin;
import com.lti.model.Application;
import com.lti.model.Application2;
import com.lti.model.Beneficiary;
import com.lti.model.CustomerApplication;
import com.lti.model.Register;
import com.lti.model.ResponseMessage;
import com.lti.model.Transactions;
import com.lti.service.CustomerService;



@RestController
@RequestMapping(path="customers")
@CrossOrigin
public class CustomerController {

	@Autowired
	private CustomerService service;
	@Autowired
	private Register reg;
	@Autowired
	private Admin admin;
	@Autowired
	private Beneficiary beneficiary;
	@Autowired
	private Account account;
    @Autowired
    private Application app;
    @Autowired
    private Transactions transaction;
    @Autowired
    private Application2 app2;
	
	private ResponseEntity<ResponseMessage> response;
	private ResponseEntity<String> response1;
   
	
	// CREATE ACCOUNT---------------------------------------
	// http://localhost:9090/customers/saving
	@RequestMapping(method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, path = "saving") 
	public ResponseEntity<ResponseMessage> addCustomer(@RequestBody CustomerApplication customer) {
		System.out.println(customer);
		boolean result=service.addCustomer(customer);
		
		if(result)
		{
		response=new ResponseEntity<ResponseMessage>(new ResponseMessage("Customer is added"),HttpStatus.OK);	
		}
		else
		{
			response=new ResponseEntity<ResponseMessage>(new ResponseMessage("Customer is not added"),HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;

	}
	
	
	
	//REGISTER--------------------------------------------------
	// http://localhost:9090/customers/register
	@RequestMapping(method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE,path="register")  
	public void register(@RequestBody Register register) {
		System.out.println(register);
		service.doRegister(register);

	}
	
	
	
	 //LOGIN-------------------------------------------------
	// http://localhost:9090/customers/sujith/sujith                                             
	@RequestMapping(path="{customerUsername}/{customerPassword}",method=RequestMethod.GET) 
	public ResponseEntity<ResponseMessage> login(@PathVariable("customerUsername") String customerUsername,@PathVariable("customerPassword") String customerPassword){
		System.out.println(customerUsername +" "+ customerPassword);
		reg.setCustomerUserName(customerUsername);
		reg.setCustomerPassword(customerPassword);
		reg=service.validate(reg.getCustomerUsername(),reg.getCustomerPassword());
		System.out.print(reg);

		if(reg==null){
			response=new ResponseEntity<ResponseMessage>(new ResponseMessage("customer is not registered"),HttpStatus.NOT_FOUND);
		}
		else{
			response=new ResponseEntity<ResponseMessage>(new ResponseMessage("login successfull"),HttpStatus.OK);
		}
		return response;
	}
	
	
	
	//FIND A
	@RequestMapping(method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Register> findAllRegisters() {
		List<Register> register = service.getRegistrations();

		return register;
	}
	
	
	
	
	@RequestMapping(method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE,path="accounts")
	public List<CustomerApplication> findAllAccounts() {
		List<CustomerApplication> register = service.getAllAccounts();

		return register;
	}
	
	
	

	// http://localhost:9090/customers/admin/                                            //ADMIN LOGIN
	@RequestMapping(path="admin/{adminid}/{adminpassword}",method=RequestMethod.GET) 
	public ResponseEntity<ResponseMessage> adminlogin(@PathVariable("adminid") String adminid,@PathVariable("adminpassword") String adminPassword){
		System.out.println(adminid+" "+ adminPassword);
		admin.setAdminId(adminid);
		admin.setAdminPassword(adminPassword);
		admin=service.check(admin.getAdminId(),admin.getAdminPassword());
		System.out.print(admin);

		if(admin==null){
			response=new ResponseEntity<ResponseMessage>(new ResponseMessage("admin is not login"),HttpStatus.NOT_FOUND);
		}
		else{
			response=new ResponseEntity<ResponseMessage>(new ResponseMessage("login successfull"),HttpStatus.OK);
		}
		return response;
	}
	

	// http://localhost:9191/customers/beneficiary
	@RequestMapping(path="beneficiary",method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<String> addBeneficiary(@RequestBody Beneficiary beneficiary) {
		ResponseEntity<String> response;
		boolean result=service.addBeneficiary(beneficiary);
		if(result)
		{
		response=new ResponseEntity<String>("Beneficiary  is added",HttpStatus.OK);	
		}
		else
		{
			response=new ResponseEntity<String>("beneficiary is not added",HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
}
	
		// http://localhost:9191/customers/emailAccNo/sujithreddy660@gmail.com       
		//DO REMEMBER TO CHANGE LESS SECURE ACCESS SETTING OF GMAIL ACCOUNT OF SENDER
		@RequestMapping(path="emailAccNo/{recepient}")                               //SEND ACCOUNT NO
		public ResponseEntity<String> sendAccountNo(@PathVariable("recepient") String recepient){
		
			
			boolean ans=service.updateCustomerStatus(recepient); 
			if(ans){
			String accountNo=app2.generateAccountNo();
			
	        boolean result=app2.sendEmailAccount(recepient, accountNo);
			//boolean result=true;
	        long acc = Long.parseLong(accountNo);
	       
	        service.addAccount(acc,recepient); //ISSUE
	        
	        
	        System.out.println("Done");
	        if(result)
			{
			response1=new ResponseEntity<String>("ACCOUNT NO SEND...",HttpStatus.OK);	
			}
			else
			{
				response1=new ResponseEntity<String>("ACCOUNT NO IS NOT SEND--...$",HttpStatus.INTERNAL_SERVER_ERROR);
			}
			return response1;}
			else{
				System.out.println("ERROR");
			}
			return response1;
			}
	
	
			// http://localhost:9191/customers/emailOTP/sujithreddy660@gmail.com
	        //DO REMEMBER TO CHANGE LESS SECURE ACCESS SETTING OF GMAIL ACCOUNT OF SENDER
			@RequestMapping(path="emailOTP/{recepient}")                                     //SEND OTP
			public ResponseEntity<String> sendEmail(@PathVariable("recepient") String recepient){
		
			String OTP=app.generatePassword();
	        boolean result=app.sendEmail(recepient, OTP);
	        
	        System.out.println("Done");
	        if(result)
			{
			response1=new ResponseEntity<String>("Email SEND...",HttpStatus.OK);	
			}
			else
			{
				response1=new ResponseEntity<String>("Email not send...$",HttpStatus.INTERNAL_SERVER_ERROR);
			}
			return response1;
			}
	
			
			// http://localhost:9191/customers/display                                 //DISPLAY ALL CUSTOMERS PENDING REQUEST
		@RequestMapping(path="display",method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
		public List<CustomerApplication> findAllCustomers() {
			List<CustomerApplication> customer = service.getCustomers();

			return customer;
		}
	
	
		//http:localhost:9191/
		@RequestMapping(method = RequestMethod.POST,consumes=MediaType.APPLICATION_JSON_VALUE,path="transaction")   //TRANSACTIONS
		public void performTransaction(@RequestBody Transactions transaction){
			
			String mode=transaction.getModeOfPayment();
			double balance=transaction.getAmountCreditDebit();
			String status=transaction.getTransactionStatus();
			String benifsc=transaction.getBeneficiaryIfsc();
			long benAcc=transaction.getBeneficiaryAccountNo();
			long userAcc=transaction.getAccountNo();
			String branch=transaction.getBranchIfsc();
			System.out.println(mode +" "+ status +" "+ balance +" "+ benifsc +" "+ benAcc +" "+ userAcc +" "+ branch);
			
			account=service.getAccountByAccountId(userAcc);
			//beneficiary=service.getAccountByAccountId(benAcc);
			System.out.println(account);
			if((userAcc==account.getAccountNo()))// && (benAcc==beneficiary.getBeneficiaryAccountNo()))
				{
				System.out.println(account.getAccountBalance());
				if(balance < account.getAccountBalance()){
					System.out.println("ONE");
					service.doMoneyTransfer(transaction);
					System.out.println("CASH");
					double balance2=account.getAccountBalance()-transaction.getAmountCreditDebit();
					System.out.println(balance2);
					service.updateAccountBalance(balance2, userAcc);
				}
			}
			
		}
		
			@ExceptionHandler(Exception.class)                    //EXCEPTION HANDLING CODE------------
			public ResponseEntity<String> handleException(Exception ex){
			ResponseEntity<String> error=new ResponseEntity<String>(ex.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
			return error;
			}
			
	}

	      

